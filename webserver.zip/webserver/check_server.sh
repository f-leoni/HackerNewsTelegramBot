#!/bin/bash

# Script per controllare e riavviare il server bookmark se non è attivo
# Da usare con cron ogni 5 minuti

# === CONFIGURAZIONE ===
SERVER_NAME="server.py"                    # Nome del file server
SERVER_PATH="/home/zitzu/hackernewsbookmarks/server.py"      # MODIFICA: Percorso assoluto al server
PYTHON_CMD="python3"                       # Comando Python
LOG_FILE="/home/zitzu/hackernewsbookmarks/server_monitor.log"     # MODIFICA: Percorso log di monitoraggio
SERVER_LOG="/home/zitzu/hackernewsbookmarks/server.log"           # MODIFICA: Percorso log del server
PID_FILE="/home/zitzu/hackernewsbookmarks/server.pid"             # MODIFICA: File PID del server

# Funzione per loggare con timestamp
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

# Funzione per controllare se il server è attivo
is_server_running() {
    # Controlla se esiste un processo che corrisponde al server
    if pgrep -f "$SERVER_NAME" > /dev/null; then
        return 0  # Server è attivo
    else
        return 1  # Server non è attivo
    fi
}

# Funzione per avviare il server
start_server() {
    log_message "Avvio del server in corso..."

    # Cambia directory dove si trova lo script
    cd "$(dirname "$SERVER_PATH")"

    # Avvia il server in background con nohup
    nohup $PYTHON_CMD "$SERVER_PATH" > "$SERVER_LOG" 2>&1 &

    # Salva il PID per reference futuro
    echo $! > "$PID_FILE"

    log_message "Server avviato con PID: $!"

    # Aspetta un momento e verifica che si sia avviato
    sleep 3
    if is_server_running; then
        log_message "Server avviato correttamente e in esecuzione"
    else
        log_message "ERRORE: Server non si è avviato correttamente"
    fi
}

# Funzione per verificare la salute del server (opzionale)
check_server_health() {
    # Verifica se il server risponde sulla porta (modifica la porta se necessario)
    local port=8443
    if command -v curl > /dev/null; then
        if curl -k -s --connect-timeout 5 "https://localhost:$port" > /dev/null; then
            return 0  # Server risponde
        else
            return 1  # Server non risponde
        fi
    else
        # Se curl non è disponibile, usa netstat o ss
        if netstat -tuln 2>/dev/null | grep ":$port " > /dev/null || ss -tuln 2>/dev/null | grep ":$port " > /dev/null; then
            return 0  # Porta in ascolto
        else
            return 1  # Porta non in ascolto
        fi
    fi
}

# === MAIN SCRIPT ===

# Crea il file di log se non esiste
touch "$LOG_FILE"

# Controlla se il server è in esecuzione
if is_server_running; then
    # Server è attivo, verifica opzionalmente la salute
    if check_server_health; then
        # Tutto OK, log solo in modalità verbose (commenta questa riga se non vuoi log continui)
        # log_message "Server attivo e funzionante"
        exit 0
    else
        log_message "ATTENZIONE: Server in esecuzione ma non risponde, riavvio forzato"
        # Uccidi il processo esistente
        pkill -f "$SERVER_NAME"
        sleep 2
        start_server
    fi
else
    log_message "Server non trovato, avvio in corso..."
    start_server
fi

# Cleanup vecchi log (mantieni solo gli ultimi 1000 righe)
if [ -f "$LOG_FILE" ]; then
    tail -n 1000 "$LOG_FILE" > "${LOG_FILE}.tmp" && mv "${LOG_FILE}.tmp" "$LOG_FILE"
fi

exit 0