#!/bin/bash

DOMAIN=oc.zitzu.it
LE_LIVE=/etc/letsencrypt/live/$DOMAIN
LE_ARCH=/etc/letsencrypt/archive/$DOMAIN

# cambia gruppo sui file live (symlink, buona pratica)
sudo chgrp ssl-cert "$LE_LIVE/fullchain.pem" "$LE_LIVE/privkey.pem"

# imposta permessi: privkey 640 (owner root rw, group r), fullchain 644 (readable)
sudo chmod 640 "$LE_LIVE/privkey.pem"
sudo chmod 644 "$LE_LIVE/fullchain.pem"

# applica i permessi anche sui file reali in archive che sono i target dei symlink
# applica i permessi anche sui file reali in archive che sono i target dei symlink
# usa find -print0 + xargs -0 per robustezza con nomi file che contengono spazi
sudo find "$LE_ARCH" -type f -name 'privkey*.pem' -print0 | sudo xargs -0 -r chgrp ssl-cert
sudo find "$LE_ARCH" -type f -name 'privkey*.pem' -print0 | sudo xargs -0 -r chmod 640
sudo find "$LE_ARCH" -type f -name 'fullchain*.pem' -print0 | sudo xargs -0 -r chgrp ssl-cert
sudo find "$LE_ARCH" -type f -name 'fullchain*.pem' -print0 | sudo xargs -0 -r chmod 644
